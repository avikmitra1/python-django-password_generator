from django.shortcuts import render
from django.http import HttpResponse
import random

# Create your views here.

def ShowMyHomePage(request):

	# without template
	#return HttpResponse('This is your home page')

	# use render
	return render(request,'generator/PG_HomePage.html')

def About(request):

	return render(request,'generator/About.html')


def Password(request):

	pswrd = ''
	chars = list('abcdefghijklmnopqrstuvwxyz')
	u_chars = list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
	n = list('0123456789')
	spcl = list('!@#$%^&*')

	# without any default value
	#length = int(request.GET.get('length'))

	# with default lngth of 6 chars long, incase no value passed
	length = int(request.GET.get('length',6))

	if request.GET.get('uppercase'):
		chars.extend(u_chars)

	if request.GET.get('numbers'):
		chars.extend(n)

	if request.GET.get('specialchar'):
		chars.extend(spcl)
	
	for x in range(length):
		pswrd = pswrd + random.choice(chars)


	return render(request,'generator/Password.html',{'password':pswrd})